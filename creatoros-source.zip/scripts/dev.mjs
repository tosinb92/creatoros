import {spawn} from 'node:child_process';
const args=process.argv.slice(2),port=args.includes('--port')?args[args.indexOf('--port')+1]:'3000';
const child=spawn(process.execPath,['node_modules/next/dist/bin/next','dev','--hostname','0.0.0.0','--port',port],{stdio:'inherit'});
process.on('SIGTERM',()=>child.kill('SIGTERM'));process.on('SIGINT',()=>child.kill('SIGINT'));child.on('exit',c=>process.exit(c??0));
