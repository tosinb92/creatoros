# CreatorOS

Public site: https://creatoros-one-blond.vercel.app

A Next.js / TypeScript application for turning long recordings into short social clips.

## Implemented

- Public marketing website and local studio, with no Vercel authentication.
- Browser video imports (200 MB / 30 minutes maximum), IndexedDB projects, search and reopen.
- Clip trimming, portrait/square/landscape reframing and manual crop.
- Editable timestamped captions, SRT import/export, colour and caption presets.
- FFmpeg WASM background worker for real MP4 rendering with AAC audio, optional logo and captions.
- Download video, cover image, caption text and SRT.
- Local brand preferences and clip approval status.
- Transcript-based editorial clip suggestions. Scores are heuristic editorial estimates, not predictions.
- On-device English ASR worker integration; see verification notes for live status.
- Supabase authentication code (signup, confirmation redirects, signin, reset and signout), disabled until its dedicated project is configured.

## Important boundaries

This is the first LOCAL version. Cloud accounts, multi-device storage, team permissions, durable cloud jobs, sharing/review links, paid subscriptions, direct publishing and social analytics are NOT active. The UI explicitly labels them unavailable. It does not show invented engagement, subscriptions or published posts.

Local processing requires an open tab. Projects are stored only in this browser; clearing browser site data removes them. Rendered exports are currently downloaded, not retained as cloud files. No source media is sent to a server in local mode. FFmpeg and speech model assets are downloaded from their respective CDNs/model hosts.

## Run

Node 24 recommended.

```
npm ci
npm run dev
npm test
npm run build
npm start
```

The dev wrapper supports a preview runner supplying --host / --port / --strictPort.

## Production

Vercel team: team_0YCbOJaEawmlSkfPhA0nlxEa
Project: prj_AvGc76o6KpPBEETqtEIC60acN12P

Deploy via source files. Automatic Git integration is not connected: the Vercel integration and GitHub connector do not currently have access to the newly created repository. A complete source archive is stored in this repository to preserve all nested source files and the package lockfile.

No secrets are included. Copy .env.example to .env.local only when the dedicated CreatorOS Supabase project is approved and provisioned. Do not use or modify another Bankole application's backend.

## Verification

- Production compile and TypeScript checks pass.
- Five media tests cover SRT timestamp handling, clipping bounds, ASS escaping and suggestion boundaries.
- Live browser imported a real 12-second H.264/AAC source; saved it; added a caption; trimmed and exported a real MP4.
- Downloaded export verified by ffprobe: H.264, 720 x 1280, AAC, exactly 5 seconds.
- Source and caption persisted after browser reload.
- Public /studio opens without a Vercel login.

## Operating costs

Local studio has no per-minute paid transcription or rendering API. Hosting and CDN bandwidth remain subject to provider limits. Browser compute and model download are borne by the user's device.

Supabase quoted USD 10 per month for a separate project in BANKOLEHQ PRO on 10 November 2026. That project has not been created pending explicit cost approval. Cloud worker hosting, media storage/egress, transactional email, publishing integration and Stripe fees will need separate confirmed estimates; USD 10 is not an all-in cloud operating cost.
