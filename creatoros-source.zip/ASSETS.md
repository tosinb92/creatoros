# CreatorOS photographic assets

These are generated editorial illustrations of fictional people, created with the built-in image-generation tool. They are not customer testimonials, real creator profiles or application screenshots. They appear only in marketing, role selection and channel-planning context.

The final campaign uses a balanced international cast. It supersedes the initial stylised and narrowly cast drafts.

| Asset | Project path | Placement |
| --- | --- | --- |
| Studio collaboration | public/assets/creatoros-hero-photo-v2.webp | Homepage hero |
| Professional clipper | public/assets/creatoros-clippers-photo-v2.webp | Clipper section and workspace role selection |
| Independent creator | public/assets/creatoros-creators-photo-v2.webp | Creator section, workspace role selection and channel portfolio |

All three are 1440 × 960 WebP derivatives, encoded at quality 86 from the generated originals. The originals are retained in the generating conversation.

## Prompt set

Shared direction: premium, realistic editorial photography for CreatorOS, a clipping and channel-building platform for an international audience. Natural skin and fabric textures, believable equipment, anatomically correct hands, contemporary charcoal studio with soft daylight and a subtle violet practical accent. Landscape 3:2. No CGI, floating objects, holograms, graphic overlays, fake statistics, text, logos, watermarks or celebrity likenesses.

1. Hero: two equally prominent collaborators, a white male podcast creator in a muted olive overshirt and a Black female editor with short natural hair, naturally discussing footage at a shared studio workstation. Real microphone, laptop, notebook, headphones, interview monitor and camera. Eye-level 50 mm editorial photography.
2. Clipper: an East Asian male professional editor with short dark hair and studio headphones, using a keyboard and mouse at a tidy desk. A real monitor shows a plausible interview and simple editing timeline. Navy overshirt, notebook, water glass, plant and soft side-window daylight. Three-quarter 50 mm portrait.
3. Creator: a South Asian female independent creator with dark wavy hair and a cream blouse, naturally recording an educational video or podcast at a timber desk. Real microphone and tripod camera, laptop with ordinary portrait-video thumbnails, warm soft daylight and a discreet lavender background practical. 85 mm editorial photograph.
