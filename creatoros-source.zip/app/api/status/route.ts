import { NextResponse } from 'next/server';
export const dynamic='force-dynamic';
// Public feature availability only. Never inspect or return credentials here.
export function GET(){return NextResponse.json({cloudWorkspace:false,backgroundProcessing:false,billing:false,publishing:false,localStudio:true,creatorDiscovery:true,creatorFeeds:true});}
