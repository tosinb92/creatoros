import Link from 'next/link';
export function Brand(){return <Link href="/" className="brand" aria-label="CreatorOS home"><span className="brand-icon">c<span>▸</span></span><span>creator<span className="brand-os">OS</span><span className="brand-dot">.</span></span></Link>}
