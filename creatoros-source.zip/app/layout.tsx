import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'CreatorOS — Run your clipping business',description:'Discover and track creators, organise sources, produce clips and manage your content operation. Built for clippers, agencies and creators.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
