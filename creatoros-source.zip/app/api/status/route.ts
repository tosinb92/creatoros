import { NextResponse } from 'next/server';
export const dynamic='force-dynamic';
export function GET(){return NextResponse.json({database:!!(process.env.NEXT_PUBLIC_SUPABASE_URL&&process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY&&process.env.SUPABASE_SERVICE_ROLE_KEY),cloudProcessing:process.env.CLOUD_PROCESSING_ENABLED==='true',billing:false,publishing:false,localStudio:true});}
