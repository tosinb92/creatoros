import {createClient} from '@supabase/supabase-js';
import {NextRequest,NextResponse} from 'next/server';
import {results} from '@/lib/vizard.mjs';

export const dynamic='force-dynamic';
export const maxDuration=60;
const fail=(message:string,status:number)=>NextResponse.json({error:message},{status,headers:{'Cache-Control':'private, no-store'}});

export async function GET(req:NextRequest) {
  const url=process.env.NEXT_PUBLIC_SUPABASE_URL,secret=process.env.SUPABASE_SERVICE_ROLE_KEY,key=process.env.VIZARD_API_KEY;
  if(!url||!secret||!key)return fail('Clip downloads are awaiting workspace configuration.',503);
  const token=req.headers.get('authorization')?.match(/^Bearer (.+)$/)?.[1];
  if(!token)return fail('Sign in to CreatorOS to download this clip.',401);
  const db=createClient(url,secret,{auth:{persistSession:false,autoRefreshToken:false}});
  const auth=await db.auth.getUser(token);
  if(auth.error||!auth.data.user)return fail('Your session expired. Sign in again.',401);
  const id=req.nextUrl.searchParams.get('id'),moment=req.nextUrl.searchParams.get('moment');
  if(!id||!moment)return fail('Clip reference is incomplete.',400);
  const row=await db.from('creatoros_link_imports').select('provider_id,state').eq('id',id).eq('owner_id',auth.data.user.id).single();
  if(row.error||row.data.state!=='processing'||!row.data.provider_id)return fail('Clip is unavailable.',404);
  try {
    const data=await results(row.data.provider_id,key);
    if(data.state!=='ready')return fail('Clip is not ready yet.',409);
    const clip=data.moments.find((item:any)=>item.id===moment);
    if(!clip)return fail('Clip has expired. Refresh the import for a new download link.',404);
    const target=new URL(clip.url);
    if(target.protocol!=='https:'||!(target.hostname==='vizard.ai'||target.hostname.endsWith('.vizard.ai')))return fail('Provider returned an unsupported download address.',502);
    const media=await fetch(target,{cache:'no-store',signal:AbortSignal.timeout(50000)});
    if(!media.ok||!media.body)return fail('Provider clip download failed. Refresh and try again.',502);
    const size=Number(media.headers.get('content-length')||0),type=media.headers.get('content-type')||'';
    if((size&&size>200*1024*1024)||!type.startsWith('video/'))return fail('Provider returned a file Studio cannot import.',502);
    return new NextResponse(media.body,{headers:{
      'Content-Type':type,'Content-Disposition':'attachment; filename="creatoros-clip.mp4"',
      'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff',
      ...(size?{'Content-Length':String(size)}:{})
    }});
  } catch { return fail('Clip download could not be confirmed. Refresh and retry.',502); }
}
