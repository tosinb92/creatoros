create table public.creatoros_link_imports (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  source_key text not null,
  source_url text not null,
  provider_id text,
  state text not null default 'submitting' check (state in ('submitting','processing','review')),
  created_at timestamptz not null default now(),
  unique (owner_id, source_key)
);
alter table public.creatoros_link_imports enable row level security;
revoke all on table public.creatoros_link_imports from public, anon;
grant select, insert, update on table public.creatoros_link_imports to authenticated;
create policy creatoros_link_imports_read_own on public.creatoros_link_imports for select to authenticated using (owner_id = auth.uid());
create policy creatoros_link_imports_create_own on public.creatoros_link_imports for insert to authenticated with check (owner_id = auth.uid());
create policy creatoros_link_imports_update_own on public.creatoros_link_imports for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
