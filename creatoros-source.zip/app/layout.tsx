import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'CreatorOS — Make more of your content',description:'Turn one recording into your next week of content. A focused workspace for discovering, editing and exporting short clips.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
